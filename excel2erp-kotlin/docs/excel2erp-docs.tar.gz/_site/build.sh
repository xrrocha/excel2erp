cd excel2erp-kotlin/docs
rm -rf _site .jekyll-cache
podman run --rm -v "$PWD:/site":Z -w /site ruby:3.2 sh -c "gem install jekyll webrick && jekyll build"
